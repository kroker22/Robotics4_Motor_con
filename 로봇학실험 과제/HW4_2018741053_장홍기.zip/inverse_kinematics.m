
%% modified DH parameter
%% 강의자료에 있는 X,Y 의 값은 end-effector의 위치
clc, clear 
%% Robot Parameter
L1 = 0.5;
L2 = 0.45;
%% %input parameter
%%x = 0; 
%%y = 0.95;

 x = 0.95;
 y = 0;
cos2 = (x^2 + y^2 - (L1^2 + L2^2)) / (2*L1*L2);
sin2 = [sqrt(1 - cos2^2),-sqrt(1 - cos2^2)]; % 1.490116119384766e-08
q2 = [atan2(sin2(1), cos2), atan2(sin2(2), cos2)];
deg_q2 = [rad2deg(q2(1)), rad2deg(q2(2))];

a = L1 + L2*cos2;
b = [L2*sin2(1), L2*sin2(2)];

cos1 = [(a*x + b(1)*y)/(a^2 + b(1)^2), (a*x + b(2)*y)/(a^2 + b(2)^2)];
sin1 = [(a*y - b(1)*x)/(a^2 + b(1)^2), (a*y - b(2)*x)/(a^2 + b(2)^2)];

q1 = [atan2(sin1(1), cos1(1)), atan2(sin1(2), cos1(2))];
deg_q1 = [rad2deg(q1(1)), rad2deg(q1(2))];
