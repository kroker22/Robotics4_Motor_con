%% 비교 해야할것
%% dc motor vs geared motor(no load) vs geared motor (load) 
v =48;
Tl = 0;

La = 0.000658; %% Termainal inductance 
Ra = 1.76; %% Termainal resistance 

jm = 0.00000995; %% rotor inertia 
b = jm / 0.00376 ;
t_constant = 0.00376;
%%friction coefficient = rotor inertia / mechanical time constant

Kt = 0.0683;%% Torque constant [Nm/A]
Ke = Kt;
PI = 3.14;


N1 = 1;
N2 = 81;
a = 0.72;
j_g = 0.0000005;                                                               
n = N1/N2;

jmg = jm  + (1/a)*(n)^2*j_g;
bmg = jmg/t_constant;


bar_m = 0.175;
bar_l = 0.3;
bar_h = 0.025;

circular_m = 0.340;
circular_r = 0.05;
circular_l = 0.3;

j_bar = 1/3 * bar_m *(bar_l^2 + 1/4*bar_h^2);
j_circular = 1/2 * circular_m * circular_r^2 + circular_m*circular_l^2;

j_load = j_bar + j_circular;
b_load = j_load /t_constant;

j_eq = jmg + (1/a)*(N1/N2)^2*j_load; %% 부하가 더해져서 나오는 공식
b_eq = j_eq/t_constant; %% 부하가 더해진 마찰력 계수




%%% 전류 상한선 25
%%% 각도 상한선 160
%%% rpm 단위 환산 --> (60 / (2 * pi))
 
result = sim("motor__homework_2.slx");

figure(1);

hold on;
plot(result.gear_cur.time, result.gear_cur.data, 'k--', 'LineWidth', 3);
plot(result.dc_cur.time, result.dc_cur.data, 'r', 'LineWidth', 1.5);

title('Current');
ylabel("current (A)");
xlabel('t (sec)');
set(gca, 'Xtick', [0 : 0.001 : 0.01]);
set(gca, 'Ytick', [0 : 2.5 : 25]);

legend("Geared motor", " DC motor");

grid on;


figure(2);

hold on;
plot(result.gear_angle.time, result.gear_angle.data ,'k', 'LineWidth', 1.5);
plot(result.dc_angle.time, result.dc_angle.data, 'r', 'LineWidth',1.5);

title("Angle");
ylabel("degree");
xlabel("t (sec)");

set(gca, 'Xtick', [0 : 0.001 : 0.01]);


legend("Geared motor", " DC motor");

grid on;


figure(3);
hold on;
plot(result.gear_velocity.time, result.gear_velocity.data * (60 / (2*pi)), 'k', 'LineWidth', 1.5 );
plot(result.dc_velocity.time, result.dc_velocity.data * (60 / (2*pi)) , 'r', 'LineWidth', 1.5);

title("Angular velocity");
xlabel('t (sec)');
ylabel('RPM');

set(gca, 'Xtick' , [0 : 0.001 : 0.01]);

legend("Geared motor", " DC motor");
grid on;



figure(4);

plot(result.attach_current.time, result.attach_current.data, 'b','Linewidth', 2);

title("Current (w/load)");
xlabel('t (sec)');
ylabel('current (A)');

set(gca, 'Xtick' , [0 : 0.001 : 0.01]);
set(gca, 'Ytick' , [0 : 2.5 : 25]);
grid on;

figure(5);

plot(result.attach_vel.time, result.attach_vel.data* (60 / (2*pi)), 'b', "LineWidth", 2);
title("Angular Velocity (w/load)");

xlabel('t (sec)');
ylabel('RPM');

set(gca, 'Xtick' , [0 : 0.001 : 0.01]);
grid on;

figure(6);

plot(result.attach_angle.time, result.attach_angle.data,'b', "LineWidth",2 );
title("Angle (w/load)");

xlabel('t (sec)');
ylabel('degree');

set(gca, 'Xtick' , [0 : 0.001 : 0.01]);
grid on;


figure(7);
plot(result.ang_diff.time, result.ang_diff.data);
title("Angle");
xlabel("t (sec)");
ylabel("degree");

grid on;

figure(8);
plot(result.vel_diff.time, result.vel_diff.data * (60 /(2 * pi)));
title("Angular velocity");
xlabel("t (sec)");
ylabel("RPM");

grid on;

