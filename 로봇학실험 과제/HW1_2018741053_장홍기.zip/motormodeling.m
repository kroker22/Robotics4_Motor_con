
v = [5 12 24 48];
Torque_Load = [0 0.5 1];

La = 0.000658; %% Termainal inductance 
Ra = 1.76; %% Termainal resistance 

j = 0.00000995; %% rotor inertia 
t = 0.00376;
b = j / t ;
%%friction coefficient = rotor inertia / mechanical time constant

Kt = 0.0683;%% Torque constant [Nm/A]
Ke = Kt;

%%각속도 제한
ytick_1 = [0 : 2.5 : 50; 0 : 5 : 100; 0 : 10 : 200; 0 : 30 : 600];
%% 각도 제한
ytick_2 = [0 : 50 : 250; 0 : 100 : 500; 0 : 200 : 1000; 0 : 500 : 2500];


v_contact= 1 ;%% v에서 5, 12 ,24, 48 골라야함
torque_contact = 1; %% 0, 0.5, 1 중에 골라야함

v_in = v(v_contact);
torque_in = Torque_Load(torque_contact);

action = sim("motor_homework_1.slx");

figure('units', 'pixels', 'pos', [350, 350, 1200, 400]);
subplot(1,2,1);
plot(action.angular_velocity.time, action.angular_velocity.data, 'b', 'LineWidth',2);

xlabel("t (sec)");
ylabel("rad/s");
xlim([0 0.1]);
ylim([0, ytick_1(v_contact, end)]);
set(gca, 'Xtick', [0 : 0.01 : 0.1]);
set(gca, 'Ytick', ytick_1(v_contact, :));
legend("Angular Velocity");

grid on;

subplot(1,2,2);
plot(action.angle.time ,action.angle.data, 'r', 'LineWidth',2);

xlabel("t (sec)");
ylabel("degrees");
xlim([0 0.1]);
ylim([0, ytick_2(v_contact, end)]);
set(gca, 'Xtick', [0 : 0.01 : 0.1]);
set(gca, 'Ytick', ytick_2(v_contact, :));
legend("Angle");

grid on;
%% 5v 0.1초 기준 각속도 36.6 정도에서 올라감
%% 5v 0.1초 기준 


